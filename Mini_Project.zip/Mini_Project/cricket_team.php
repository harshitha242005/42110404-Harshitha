<?php
// Database connection parameters
$servername = "localhost"; // Replace with your server name
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$database = "cricket_team_db"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $names = $_POST['name'];
    $battingOrders = $_POST['battingOrder'];
    $battingStyles = $_POST['battingStyle'];
    $bowlingStyles = $_POST['bowlingStyle'];
    $additionalResponsibilities = $_POST['additionalResponsibility'];
    
    // Prepare the SQL statement
    $stmt = $conn->prepare("INSERT INTO players (name, batting_order, batting_style, bowling_style, additional_responsibility) VALUES (?, ?, ?, ?, ?)");
    
    // Loop through the form data and execute the statement for each player
    for ($i = 0; $i < count($names); $i++) {
        $name = $names[$i];
        $battingOrder = $battingOrders[$i];
        $battingStyle = $battingStyles[$i];
        $bowlingStyle = $bowlingStyles[$i];
        $additionalResponsibility = $additionalResponsibilities[$i];
        
        // Bind parameters and execute the statement
        $stmt->bind_param("sisss", $name, $battingOrder, $battingStyle, $bowlingStyle, $additionalResponsibility);
        $stmt->execute();
    }
    
    // Close the statement and connection
    $stmt->close();
    $conn->close();
    
    echo "<p>Data inserted successfully</p>";
}
?>